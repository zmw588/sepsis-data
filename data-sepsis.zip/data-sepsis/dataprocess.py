# -*- coding: utf-8 -*-
"""
Created on Sat Jul 10 16:42:53 2021

@author: 417-02
"""

from scipy.interpolate import interp1d
from numpy import transpose
import numpy as np
from matplotlib import pyplot as plt
import pandas as pd
from sklearn.metrics import mean_squared_error
#df_orig = pd.read_csv('https://raw.githubusercontent.com/selva86/datasets/master/a10.csv', parse_dates=['date'], index_col='date').head(100)
'''
df = pd.read_csv('K:/SepsisPrediction-master/data/sepsis/train/12.csv', parse_dates=['record_time'], index_col='record_time')
 
fig, axes = plt.subplots(7, 1, sharex=True, figsize=(10, 12))
plt.rcParams.update({'xtick.bottom' : False})
 
## 1. Actual -------------------------------
#df_orig.plot(title='Actual', ax=axes[0], label='Actual', color='red', style=".-")
df.plot(title='Actual', ax=axes[0], label='Actual', color='green', style=".-")
axes[0].legend(["Missing Data", "Available Data"])
 
## 2. Forward Fill --------------------------
df_ffill = df.ffill()
#error = np.round(mean_squared_error(df_orig['value'], df_ffill['value']), 2)
df_ffill['record_time'].plot(ax=axes[1], label='Forward Fill', style=".-")
 
## 3. Backward Fill -------------------------
df_bfill = df.bfill()
#error = np.round(mean_squared_error(df_orig['value'], df_bfill['value']), 2)
df_bfill['value'].plot(ax=axes[2], label='Back Fill', color='firebrick', style=".-")
 
## 4. Linear Interpolation ------------------
df['rownum'] = np.arange(df.shape[0])
df_nona = df.dropna(subset = ['value'])
f = interp1d(df_nona['rownum'], df_nona['value'])
df['linear_fill'] = f(df['rownum'])
#error = np.round(mean_squared_error(df_orig['value'], df['linear_fill']), 2)
df['linear_fill'].plot(ax=axes[3], label='Cubic Fill', color='brown', style=".-")
 
## 5. Mean of 'n' Nearest Past Neighbors ------def knn_mean(ts, n):
'''    
'''
out = np.copy(ts)
    for i, val in enumerate(ts):
        if np.isnan(val):
            n_by_2 = np.ceil(n/2)
            lower = np.max([0, int(i-n_by_2)])
            upper = np.min([len(ts)+1, int(i+n_by_2)])
            ts_near = np.concatenate([ts[lower:i], ts[i:upper]])
            out[i] = np.nanmean(ts_near)
    return out
 
df['knn_mean'] = knn_mean(df.value.values, 8)
error = np.round(mean_squared_error(df_orig['value'], df['knn_mean']), 2)
df['knn_mean'].plot(title="KNN Mean (MSE: " + str(error) +")", ax=axes[5], label='KNN Mean', color='tomato', alpha=0.5, style=".-")
'''
# create a dataframe with an integer feature and a categorical string feature
import numpy as np
import os
import pickle
import pandas as pd
from datetime import datetime
from datetime import timedelta

PATH_TRAIN = "D:/sepsis/SepsisPrediction-master/data/sepsis/train/train_sample_cleaned_pivoted_vital.csv"
PATH_VALIDATION = "D:/sepsis/SepsisPrediction-master/data/sepsis/validation/valid_sample_cleaned_pivoted_vital.csv"
PATH_TEST = "D:/sepsis/SepsisPrediction-master/data/sepsis/test/test_sample_cleaned_pivoted_vital.csv"
PATH_OUTPUT = "./../../data/sepsis/processed_data/"
df1 = pd.read_csv(PATH_TRAIN)
df2 = pd.read_csv(PATH_VALIDATION)
df3 = pd.read_csv(PATH_TEST)
df = pd.concat([df1,df2])
dff = pd.concat([df,df3])

def create_dataset(dff, observation_window=3, prediction_window=0):
    """
    :param path: path to the directory contains raw files.
    :param observation window: time interval we will use to identify relavant events
    :param prediction window: a fixed time interval that is to be used to make the prediction
    :return: List(pivot vital records), List(labels), time sequence data as a List of List of List.
    """
    seqs = []
    labels = []
    # load data from csv;
    df = dff
    a=0
    b=0

    # construct features
    grouped_df = df.groupby('icustay_id')
    for name, group in grouped_df: 
        if group.iloc[-1, -1]==1:
            a=a+1
        elif group.iloc[-1, -1]==0:
             b=b+1
        # calculate the index_hour
        # for the patients who have the sepsis, index hour is #prediction_window hours prior to the onset time
        # for the patients who don't have the sepsis, index hour is the last event time 
        #print(group)
        index_hour = datetime.strptime(group.iloc[-1,1], '%Y-%m-%d %H:%M:%S') - timedelta(hours=prediction_window)
        
        group['record_time'] = pd.to_datetime(group['record_time'])
        helper = pd.DataFrame({'record_time': pd.date_range(group['record_time'].min(), group['record_time'].max(), freq='H')})

        group = pd.merge(group, helper, on='record_time', how='outer').sort_values('record_time')
        #print(df)

        group = group.interpolate(method='linear')

        # get the date in observation window
        group['record_time'] = pd.to_datetime(group['record_time'])
        data1 = group.iloc[:, 2:-3]
        #print(len(data1))
        #print(group['record_time'])
        if len(data1)-observation_window>1:
            aa=2
        else:
            aa=len(data1)-observation_window
        for i in range(aa):
           record_seqs = []
           
           filterd_group = group[(group['record_time'] > (index_hour - timedelta(hours=observation_window+i))) & (group['record_time'] <= (index_hour - timedelta(hours=i)))]
        # construct the records seqs and label seqs
           data = filterd_group.iloc[:, 2:-3]
           for i in range(0, data.shape[0], 1):
              record_seqs.append(data.iloc[i].tolist())
           #print(len(record_seqs))

           if len(record_seqs) != 0:
              seqs.append(record_seqs)
              if filterd_group.iloc[-1, -1]>=0.5:
                  filterd_group.iloc[-1, -1]=1
              else:
                  filterd_group.iloc[-1, -1]=0
              labels.append(filterd_group.iloc[-1, -1])
    seqs=np.array(seqs)
    labels=np.array(labels)
    print(seqs.shape)
    print(labels.shape)
    print(a)
    print(b)
    return seqs, labels


def main():
    os.makedirs(PATH_OUTPUT, exist_ok=True)
    # Train set
    print("Construct train set")
    train_seqs, train_labels = create_dataset(dff)
    #print(train_seqs)
    print(train_seqs.shape)
    print(train_labels.shape)
    print(train_labels[:1000])
    #print(train_seqs)
    #np.save('D:/sepsis/SepsisPrediction-master/data/sepsis/processed_data/sepsis.seqs3,0.npy',train_seqs)
    #np.save('D:/sepsis/SepsisPrediction-master/data/sepsis/processed_data/sepsis.labels3,0.npy',train_labels)

if __name__ == '__main__':
    main() 
            
    